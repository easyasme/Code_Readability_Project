#!/bin/python3

import sys, re
from util import *

p, d, t, year, day, inp, lines, expected_ans = getArgs()

## you don't want to print a lot of debug info if you aren't in debug mode!
if not d:
    real_print = print
    print = lambda *args, **kwargs: None

# some helpful information:
# the variable p stores what part you are currently on, it's either 1 or 2
# make your script work with both parts by using if p == 1: ... else: ...
# the variable d is a boolean; it returns if you are in debug mode or not
# the submit function works 
# the variable t is a boolean; it returns if you are in test mode or not
ans = 'No answer calculated yet'

map = {}
for y in rl(lines):
    for x in rl(lines[y]):
        map[(x,y)] = lines[y][x]

def getPoint(x,y):
    try:
        return map[(x,y)]
    except:
        return '.'

def getDirMapping(d):
    # (N, E, S, W)
    if d == 'N':
        return (0, -1)
    elif d == 'E':
        return (1, 0)
    elif d == 'S':
        return (0, 1)
    elif d == 'W':
        return (-1, 0)
dirs = ['N', 'S', 'W', 'E']

#addPosToMap = lambda pos, map: '\n'.join(map[max(0,pos[1]-2):pos[1]] + [map[pos[1]][:pos[0]] + 'X' + map[pos[1]][pos[0]+1:]] + map[pos[1]+1:pos[1]+3])
#addPosToMap = lambda pos, map: '\n'.join(map[:pos[1]] + [map[pos[1]][:pos[0]] + 'X' + map[pos[1]][pos[0]+1:]] + map[pos[1]+1:])
# check:
# #######
# .DDEDD.
# where E is elf
# and # is wall
# and D is different elf
# and . is empty space
# rotate check for the right direction
def check(x, y, d):
    a = x == 4 and y == 0
    toCheck = [(-1, -1), (0, -1), (1, -1)] 
    for _ in rl(toCheck):
        dx, dy = getDirMapping(d)
        if dx == -1:
            toCheck[_] = (toCheck[_][1], toCheck[_][0])
        elif dy == 1:
            toCheck[_] = (toCheck[_][0], -toCheck[_][1])
        elif dx == 1:
            toCheck[_] = (-toCheck[_][1], toCheck[_][0])

    checkPass = True
    if a: print(dx, dy, toCheck)
    for _ in rl(toCheck):
        if a: print(toCheck[_], getPoint(x+toCheck[_][0], y+toCheck[_][0]))
        if getPoint(x+toCheck[_][0], y+toCheck[_][0]) != '.':
            checkPass = False
    if a: print(checkPass)
    return checkPass

## your code goes here
if p == 1:
    # ans = 1337
    print('round 0')
    print_board(map)
    proposed_moves = {}
    for x, y in map.copy():
        if map[(x,y)] != '#':
               continue
        for dir in dirs:
            if check(x, y, dir):
                dx, dy = getDirMapping(dir)
                if (x+dx, y+dy) not in proposed_moves: proposed_moves[(x+dx, y+dy)] = (x, y, dir)
                break
    for move in proposed_moves:
        x, y, dir = proposed_moves[move]
        map[move] = map[(x,y)]
        del map[(x,y)]
    print('round 1')

    print_board(map)
    pass
else: ## part 2
    # ans = 13371337
    pass

## restore print
if not d:
    print = real_print

## place log info down here that you want shown even when running on the real large input
# print_board(board)

## submit answer you got to the utils function
final(t, p, ans, expected_ans)
